


RIDDLES
-poppers riddle


Before the party, call the driver,

I whip and I crack and I help you finish a cake
to make the cream
. After the party, you'll huff and puff with all my might, oh degenerate delight.  What am I? 
In a group we shake and rattle, 

Strict instructions but I keep things loose
%Odours strong but I'm not for jocks
Not orange or apple but still a juice
twinks and jocks, douches and divas
on the dancefloor, we're all believers 
what am i?

add, adhd
%head in the clcloudhelp bring me down the ground
helps to learn but more often youll gurn
lightning quick but misguided 
at the club bottles divided
dexies


