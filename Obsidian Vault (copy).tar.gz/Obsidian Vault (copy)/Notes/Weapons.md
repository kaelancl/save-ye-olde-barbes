Barbarian (Strong)
VB Long neck - Melee damage buff 
Meth pipe - Dex, strength - accuracy down activated 


Ranger (Range)

Wizard (healer)

Wallet including:
Smart rider - teleport
timezone - gamer rush - dexterity buff
DOME Loyalty - Every third use redeem to sleep enemy on hit. Regularly gives disadvantage to attacks 
Coles group and Myer $50 gift card ($24.25 Remaining) - Deals damage, and damage over time

Bard (Rizz)
199 Best Pickup line book - Increase to persuasion 
Guitar picks - Deals damage, and damage over time
Megaphone - Small damage to everyone in ear shot (also amplifies voice)
Bottle of dexies - Advantage to charisma when shared also fast and whatever 

Rogue(Stealth)

