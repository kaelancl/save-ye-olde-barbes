1) Blank Cone Kyle smoked many a cone... but how many? Answer: 10
2) Ancient travellers of Bali once climbed a volcano. What was name of volcano? Answer: Mount Batur
3) What was for dinner on NYE 2024? Answer: Mexican
4) The same ancient travellers went to a club in Bali. What was its name? 
	a) Red Curtain b) Potato Head Beach Club c) Blue Door d) Green Machine

