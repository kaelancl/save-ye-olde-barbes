 Character sheets
	 npcs 
		 characteristics/personality
		
	players
Fight mechanics
	Health balancing 
	how many grunts
	Stats 
Script location descriptions and expositionish

Think of ways to skip ahead or side quests to slow down